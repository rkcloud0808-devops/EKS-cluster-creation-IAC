terraform {
  required_version = ">= 1.5.7, < 2.0.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "6.52.0"
    }

    tls = {
      source  = "hashicorp/tls"
      version = "4.3.0"
    }

    time = {
      source  = "hashicorp/time"
      version = "0.14.0"
    }
  }
}