# ============================================================
# ag-noprod-ap - Non-production EKS cluster
#
# ACCOUNT_ID and ROLE_NAME may be injected by CI/CD through
# TF_VAR_ACCOUNT_ID and TF_VAR_ROLE_NAME.
#
# Infrastructure account:
#   263975812908
#
# Shared addon image account:
#   044063822467
# ============================================================

ACCOUNT_ID = "263975812908"
ROLE_NAME  = "Jenkins"

################################################################################
# Cluster
################################################################################

vpc_id = "vpc-04bbd4d0e7d108919"

# EKS control-plane and worker-node primary ENI subnets.
subnet_ids = [
  "subnet-0372d86e924acec69",
  "subnet-01119122d32956b66"
]

cluster_name    = "ag-noprod-ap-eks-136"
cluster_region  = "ap-southeast-1"
cluster_version = "1.36"

cluster_endpoint_public_access = false

################################################################################
# AWS VPC CNI Custom Networking
#
# Nodes use subnet_ids above for their primary ENIs.
# Pods use the dedicated AZ-specific subnets below through secondary ENIs.
#
# ENIConfig resources must be named after the corresponding Availability Zone
# because the VPC CNI is configured with:
#
# ENI_CONFIG_LABEL_DEF = "topology.kubernetes.io/zone"
#
# IMPORTANT:
# Replace the placeholder values below with the confirmed NonProd Pod-subnet
# IDs from account 263975812908 and VPC vpc-04bbd4d0e7d108919.
################################################################################

enable_eni_config = false
vpc_cni_custom_networking = false

pod_subnet_ids = {
  "ap-southeast-1a" = "subnet-003cf7f8c738c3f76"
  "ap-southeast-1b" = "subnet-0e57f8343cc5ac507"
  "ap-southeast-1c" = "subnet-02360d0c49cdef4e1"
}

################################################################################
# Existing Phase 1 IAM Roles
#
# These roles and the Karpenter instance profile must be created by the
# dedicated IAM Terraform stack before the EKS deployment.
################################################################################

eks_cluster_role_arn = "arn:aws:iam::263975812908:role/ag-nonprod-ap-eks-cluster-role"

eks_managed_node_role_arn = "arn:aws:iam::263975812908:role/ag-nonprd-ap-eks-managed-node-role"

karpenter_node_role_arn = "arn:aws:iam::263975812908:role/ag-nonprd-ap-karpenter-node-role"

karpenter_node_role_name = "ag-nonprd-ap-karpenter-node"

karpenter_node_instance_profile_name = "ag-nonprd-ap-karpenter-node"

################################################################################
# Addon Feature Flags
################################################################################

enable_cluster_autoscaler           = false
enable_karpenter                    = true
enable_velero                       = true
enable_gatekeeper                   = false
enable_aws_load_balancer_controller = true
enable_aws_for_fluentbit            = false
enable_aws_node_termination_handler = false
enable_aws_cloudwatch_metrics       = true
enable_vpa                          = true
enable_metrics_server               = true

################################################################################
# Common Tags
################################################################################

tags = {
  "appcode"                      = "APP04246"
  "AppEnv"                       = "UAT"
  "AwsEnv"                       = "UAT"
  "Application"                  = "APAC_EKS_NPRD_CLUSTER"
  "Name"                         = "APAC_EKS_NPRD_CLUSTER"
  "Project"                      = "APAC_EKS_NPRD_CLUSTER"
  "AwsId"                        = "hnyjvmy57dfgenfzhrvp"
  "archiving"                    = "no"
  "backup"                       = "yes"
  "data-confidentiality"         = "C2"
  "finops.automation.schedule"   = "running"
  "finops.id"                    = "hnyjvmy57dfgenfzhrvp"
  "info.eol"                     = "Null"
  "info.owner"                   = "APAC.cloud@cma-cgm.com"
  "msp"                          = "NTT"
}

################################################################################
# EKS Managed Node Groups
#
# The CriticalAddonsOnly taint is intentionally not configured.
#
# The ARM64 On-Demand managed node group supplies stable baseline capacity for
# critical cluster and system workloads.
#
# The existing x86 Spot managed node group is retained from the supplied
# NonProd configuration. Karpenter also provides dynamic ARM64 and AMD64 Spot
# capacity through the shared NodePool configuration.
################################################################################

eks_managed_node_groups = {
  ondemand-arm = {
    instance_types = [
      "t4g.large",
      "t4g.xlarge",
      "t4g.2xlarge"
    ]

    ami_type                   = "AL2023_ARM_64_STANDARD"
    create_launch_template     = false
    use_custom_launch_template = false

    min_size     = 1
    max_size     = 3
    desired_size = 2

    capacity_type              = "ON_DEMAND"
    enable_bootstrap_user_data = true
    ebs_optimized              = true
    disable_api_termination    = false
    encrypted_volume           = true
    enable_monitoring          = true

    labels = {
      "capacity-type" = "on-demand"
      "workload-arch" = "arm64"
    }

    taints = []

    launch_template_tags = {
      "karpenter.sh/ekscluster" = "ag-noprod-ap"
    }
  }

  spot-x86 = {
    instance_types = [
      "m6i.2xlarge",
      "m6a.2xlarge",
      "m7i.2xlarge",
      "m7i-flex.2xlarge",
      "c6i.2xlarge",
      "c6a.2xlarge",
      "c7i.2xlarge",
      "r6i.2xlarge",
      "r6a.2xlarge",
      "r7i.2xlarge"
    ]

    ami_type                   = "AL2023_x86_64_STANDARD"
    create_launch_template     = false
    use_custom_launch_template = false

    min_size     = 1
    max_size     = 3
    desired_size = 1

    capacity_type              = "SPOT"
    enable_bootstrap_user_data = true
    ebs_optimized              = true
    disable_api_termination    = false
    encrypted_volume           = true
    enable_monitoring          = true

    labels = {
      "capacity-type" = "spot"
      "workload-arch" = "amd64"
    }

    taints = []

    launch_template_tags = {
      "karpenter.sh/ekscluster" = "ag-noprod-ap"
    }
  }
}

################################################################################
# Generic Helm Releases
#
# The add-on images are hosted in the shared DevOps ECR account:
# 044063822467
#
# The NonProd managed-node and Karpenter-node IAM roles must have permission to
# pull images from the shared ECR repositories.
#
# timeout is included in every release because helm_releases is a map and all
# map elements must have a consistent object structure.
################################################################################

helm_releases = {
  cilium = {
    description      = "Cilium networking and policy with Hubble UI"
    namespace        = "cilium"
    create_namespace = true
    chart            = "cilium"
    chart_version    = "1.16.5"
    repository       = "https://helm.cilium.io/"
    timeout          = 900

    values = [
      <<-EOT
        hubble:
          enabled: true
          relay:
            enabled: true
          ui:
            enabled: true

        cni:
          chainingMode: aws-cni
          exclusive: false

        enableIPv4Masquerade: false
        enableIPv6Masquerade: false
        routingMode: native
      EOT
    ]
  }

  kubetail = {
    description      = "Cluster-wide log tailing UI"
    namespace        = "kubetail"
    create_namespace = true
    chart            = "kubetail"
    chart_version    = "0.6.0"
    repository       = "https://kubetail-org.github.io/helm-charts/"
    timeout          = 900

    values = [
      <<-EOT
        clusterRole: true

        nodeSelector:
          capacity-type: on-demand
      EOT
    ]
  }

  goldilocks = {
    description      = "VPA-based right-sizing recommendations"
    namespace        = "goldilocks"
    create_namespace = true
    chart            = "goldilocks"
    chart_version    = "9.0.1"
    repository       = "https://charts.fairwinds.com/stable"
    timeout          = 900

    values = [
      <<-EOT
        image:
          repository: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com/eks/goldilocks
          tag: v4.13.0
          pullPolicy: IfNotPresent

        # VPA is installed separately by the EKS addons module.
        vpa:
          enabled: false
      EOT
    ]
  }

  kyverno = {
    description      = "Kubernetes policy engine"
    namespace        = "kyverno"
    create_namespace = true
    chart            = "kyverno"
    chart_version    = "3.4.5"
    repository       = "https://kyverno.github.io/kyverno/"
    timeout          = 900

    values = [
      <<-EOT
        crds:
          migration:
            image:
              registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
              repository: eks/kyverno-cli
              tag: v1.14.5
              pullPolicy: IfNotPresent

        webhooksCleanup:
          image:
            registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
            repository: eks/kubectl
            tag: "1.33.4"
            pullPolicy: IfNotPresent

        policyReportsCleanup:
          image:
            registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
            repository: eks/kubectl
            tag: "1.33.4"
            pullPolicy: IfNotPresent

        admissionController:
          replicas: 3

          initContainer:
            image:
              registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
              repository: eks/kyvernopre
              tag: v1.14.5
              pullPolicy: IfNotPresent

          container:
            image:
              registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
              repository: eks/kyverno
              tag: v1.14.5
              pullPolicy: IfNotPresent

          nodeSelector:
            capacity-type: on-demand

        backgroundController:
          image:
            registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
            repository: eks/kyverno-background-controller
            tag: v1.14.5
            pullPolicy: IfNotPresent

          nodeSelector:
            capacity-type: on-demand

        cleanupController:
          image:
            registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
            repository: eks/kyverno-cleanup-controller
            tag: v1.14.5
            pullPolicy: IfNotPresent

          nodeSelector:
            capacity-type: on-demand

        reportsController:
          image:
            registry: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com
            repository: eks/kyverno-reports-controller
            tag: v1.14.5
            pullPolicy: IfNotPresent

          nodeSelector:
            capacity-type: on-demand
      EOT
    ]
  }

  keda = {
    description      = "Kubernetes Event-driven Autoscaling"
    namespace        = "keda"
    create_namespace = true
    chart            = "keda"
    chart_version    = "2.16.1"
    repository       = "https://kedacore.github.io/charts"
    timeout          = 900

    values = [
      <<-EOT
        operator:
          replicaCount: 2

        metricsServer:
          replicaCount: 2
      EOT
    ]
  }

  prometheus-adapter = {
    description      = "Prometheus adapter for custom metrics API"
    namespace        = "prometheus-adapter"
    create_namespace = true
    chart            = "prometheus-adapter"
    chart_version    = "4.11.0"
    repository       = "https://prometheus-community.github.io/helm-charts"
    timeout          = 900

    values = [
      <<-EOT
        image:
          repository: 044063822467.dkr.ecr.ap-southeast-1.amazonaws.com/eks/prometheus-adapter
          tag: v0.12.0
          pullPolicy: IfNotPresent

        replicas: 2

        podDisruptionBudget:
          enabled: true
      EOT
    ]
  }
}

################################################################################
# Velero
################################################################################

# Back up only NonProd application namespaces.
velero_backup_namespaces = [
  "apac_dev",
  "apac_sit",
  "apac_uat"
]