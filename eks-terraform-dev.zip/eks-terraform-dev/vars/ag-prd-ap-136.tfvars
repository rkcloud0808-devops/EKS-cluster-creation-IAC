# ============================================================
# ag-prd-ap — Production cluster
# ACCOUNT_ID, ROLE_NAME, cluster_kms_key_arn, velero_kms_key_arn
# are injected by CI/CD as TF_VAR_* environment variables.
# ============================================================

vpc_id          = "vpc-0e9cf95c1cb90c8df"
subnet_ids      = ["subnet-012f8e00497060c21", "subnet-0d6efaf8dffa7cb98", "subnet-0704f56634c212656"]
cluster_name    = "ag-prd-ap"
cluster_region  = "ap-southeast-1"
cluster_version = "1.36"

cluster_endpoint_public_access = false

enable_cluster_autoscaler           = false
enable_karpenter                    = true
enable_velero                       = true
enable_gatekeeper                   = false
enable_aws_load_balancer_controller = true
enable_aws_for_fluentbit            = false
enable_aws_node_termination_handler = true
enable_aws_cloudwatch_metrics       = true
enable_vpa                          = true
enable_metrics_server               = true

tags = {
  appcode                      = "APP04246"
  AppEnv                       = "PRD"
  AwsEnv                       = "PRD"
  Application                  = "APAC_EKS_PROD_CLUSTER"
  Name                         = "APAC_EKS_PROD_CLUSTER"
  Project                      = "APAC_EKS_PROD_CLUSTER"
  AwsId                        = "hnyjvmy57dfgenfzhrvp"
  archiving                    = "no"
  backup                       = "yes"
  "data-confidentiality"       = "C2"
  "finops.automation.schedule" = "running"
  "finops.id"                  = "hnyjvmy57dfgenfzhrvp"
  "info.eol"                   = "Null"
  "info.owner"                 = "APAC.cloud@cma-cgm.com"
  msp                          = "NTT"
}

eks_managed_node_groups = {
  ondemand-arm = {
    instance_types = [
      "m7g.large", "m7g.xlarge", "m7g.2xlarge",
      "m6g.large", "m6g.xlarge", "m6g.2xlarge",
      "c7g.large", "c7g.xlarge", "c7g.2xlarge",
      "c6g.large", "c6g.xlarge", "c6g.2xlarge",
      "r7g.large", "r7g.xlarge", "r7g.2xlarge",
      "r6g.large", "r6g.xlarge", "r6g.2xlarge"
    ]
    ami_type                   = "AL2023_ARM_64_STANDARD"
    create_launch_template     = false
    use_custom_launch_template = false
    min_size                   = 2
    max_size                   = 4
    desired_size               = 2
    capacity_type              = "ON_DEMAND"
    enable_bootstrap_user_data = true
    ebs_optimized              = true
    disable_api_termination    = false
    encrypted_volume           = true
    enable_monitoring          = true
    labels = {
      "capacity-type" = "on-demand"
    }
    taints = [
      { key = "CriticalAddonsOnly", value = "true", effect = "NO_SCHEDULE" }
    ]
    launch_template_tags = {
      "karpenter.sh/ekscluster" = "ag-prd-ap"
    }
  }

  spot-x86 = {
    instance_types = [
      "m6i.2xlarge", "m6a.2xlarge", "m7i.2xlarge", "m7i-flex.2xlarge",
      "c6i.2xlarge", "c6a.2xlarge", "c7i.2xlarge",
      "r6i.2xlarge", "r6a.2xlarge", "r7i.2xlarge"
    ]
    ami_type                   = "AL2023_x86_64_STANDARD"
    create_launch_template     = false
    use_custom_launch_template = false
    min_size                   = 1
    max_size                   = 4
    desired_size               = 1
    capacity_type              = "SPOT"
    enable_bootstrap_user_data = true
    ebs_optimized              = true
    disable_api_termination    = false
    encrypted_volume           = true
    enable_monitoring          = true
    labels = {
      "capacity-type" = "spot"
    }
    launch_template_tags = {
      "karpenter.sh/ekscluster" = "ag-prd-ap"
    }
  }
}

helm_releases = {
  cilium = {
    description      = "Cilium service mesh with Hubble UI"
    namespace        = "cilium"
    create_namespace = true
    chart            = "cilium"
    chart_version    = "1.16.5"
    repository       = "https://helm.cilium.io/"
    values = [
      <<-EOT
        hubble:
          enabled: true
          relay:
            enabled: true
          ui:
            enabled: true
        cni:
          chainingMode: generic-veth
          customConf: true
          configMap: cni-configuration
        enableIPv4Masquerade: false
        enableIPv6Masquerade: false
        routingMode: native
      EOT
    ]
  }
  kubetail = {
    description      = "Cluster-wide log tailing UI"
    namespace        = "kubetail"
    create_namespace = true
    chart            = "kubetail"
    chart_version    = "0.6.0"
    repository       = "https://kubetail-org.github.io/helm-charts/"
    values           = ["clusterRole: true\n"]
  }
  goldilocks = {
    description      = "VPA-based right-sizing recommendations"
    namespace        = "goldilocks"
    create_namespace = true
    chart            = "goldilocks"
    chart_version    = "9.0.1"
    repository       = "https://charts.fairwinds.com/stable"
    values           = ["vpa:\n  enabled: true\n"]
  }
  kyverno = {
    description      = "Kubernetes policy engine"
    namespace        = "kyverno"
    create_namespace = true
    chart            = "kyverno"
    chart_version    = "3.3.4"
    repository       = "https://kyverno.github.io/kyverno/"
    values = [
      <<-EOT
        admissionController:
          replicas: 3
          nodeSelector:
            capacity-type: on-demand
          tolerations:
            - key: "CriticalAddonsOnly"
              operator: "Exists"
        backgroundController:
          nodeSelector:
            capacity-type: on-demand
        cleanupController:
          nodeSelector:
            capacity-type: on-demand
        reportsController:
          nodeSelector:
            capacity-type: on-demand
      EOT
    ]
  }
  keda = {
    description      = "Kubernetes Event-driven Autoscaling"
    namespace        = "keda"
    create_namespace = true
    chart            = "keda"
    chart_version    = "2.16.1"
    repository       = "https://kedacore.github.io/charts"
    values = [
      <<-EOT
        operator:
          replicaCount: 2
        metricsServer:
          replicaCount: 2
      EOT
    ]
  }
  prometheus-adapter = {
    description      = "Prometheus adapter for custom metrics API"
    namespace        = "prometheus-adapter"
    create_namespace = true
    chart            = "prometheus-adapter"
    chart_version    = "4.11.0"
    repository       = "https://prometheus-community.github.io/helm-charts"
    values           = ["replicas: 2\npodDisruptionBudget:\n  enabled: true\n"]
  }
}

# Velero: back up only Production application namespace
velero_backup_namespaces = ["apac_prd"]
