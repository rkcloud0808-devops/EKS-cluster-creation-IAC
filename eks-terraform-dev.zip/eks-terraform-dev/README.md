# EKS Terraform Code — APAC Cloud

Terraform IaC for provisioning and managing Amazon EKS clusters across APAC AWS accounts (DevOps, NonProd, Prod).

---

## Cluster Design

### Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         VPC (Dedicated)                          │
├──────────────┬──────────────┬──────────────┬────────────────────┤
│ Ingress Ext  │ Ingress Int  │  Node Subnet │  Pod Subnet (CNI)  │
│   Subnet     │   Subnet     │              │  (non-routable)    │
└──────────────┴──────────────┴──────┬───────┴─────────┬──────────┘
                                     │                 │
                              EKS Managed        Pods egress via
                              Node Groups        NAT Gateway
```

- **VPC CNI Custom Networking**: Pods run on dedicated non-routable subnets, egress via NAT gateway
- **Prefix Delegation**: Enabled to maximize IP density per ENI on Graviton nodes
- **Private Cluster**: API server endpoint is private-only (`cluster_endpoint_public_access = false`)
- **Secrets Encryption**: KMS envelope encryption for Kubernetes secrets at rest (optional, via `cluster_kms_key_arn`)

### Node Groups

#### DevOps Cluster (ARM-only)

| Group | Architecture | Capacity | Instance Types | Sizing |
|-------|-------------|----------|----------------|--------|
| `ondemand-arm` | ARM64 (Graviton) | ON_DEMAND | m7g, m6g, c7g, c6g (.large–.2xlarge) | min=2, max=4, desired=2 |

DevOps runs fully on ARM. Karpenter provisions additional ARM spot nodes for workloads.

#### NonProd Cluster

| Group | Architecture | Capacity | Instance Types | Sizing |
|-------|-------------|----------|----------------|--------|
| `ondemand-arm` | ARM64 (Graviton) | ON_DEMAND | t4g (.large–.2xlarge) | min=1, max=3, desired=2 |
| `spot-x86` | x86_64 | SPOT | m6i/m6a/m7i/c6i/c6a/c7i/r6i/r6a/r7i (.2xlarge) | min=1, max=3, desired=1 |

#### Prod Cluster

| Group | Architecture | Capacity | Instance Types | Sizing |
|-------|-------------|----------|----------------|--------|
| `ondemand-arm` | ARM64 (Graviton) | ON_DEMAND | m7g/m6g/c7g/c6g/r7g/r6g (.large–.2xlarge) | min=2, max=4, desired=2 |
| `spot-x86` | x86_64 | SPOT | m6i/m6a/m7i/c6i/c6a/c7i/r6i/r6a/r7i (.2xlarge) | min=1, max=4, desired=1 |

#### Common Design

- On-demand ARM nodes have taint `CriticalAddonsOnly=true:NoSchedule` — only critical addons (Karpenter, Kyverno, CoreDNS, KEDA) schedule here
- Karpenter manages additional capacity beyond the managed node groups via NodePool/EC2NodeClass
- Karpenter NodePool instances capped at **4xlarge** maximum
- IMDSv2 enforced (`http_tokens = required`)
- No static AMI IDs — `ami_type = AL2023_ARM_64_STANDARD` / `AL2023_x86_64_STANDARD`

### Scaling Strategy

1. **Managed Node Groups** — provide baseline capacity for control-plane addons
2. **Karpenter** — handles dynamic scaling for workloads (ARM Graviton + x86 spot diversification)
3. **KEDA** — event-driven pod autoscaling (scales Deployments based on external metrics)
4. **VPA/Goldilocks** — right-sizing recommendations for resource requests

---

## Addons

### EKS Managed Addons (always deployed)

| Addon | Purpose |
|-------|---------|
| `vpc-cni` | Pod networking with custom networking + prefix delegation |
| `coredns` | Cluster DNS (HA: 2 replicas, anti-affinity, topology spread) |
| `kube-proxy` | Network proxy |
| `eks-pod-identity-agent` | Pod Identity for IRSA replacement |
| `aws-ebs-csi-driver` | EBS persistent volumes |
| `amazon-cloudwatch-observability` | Container Insights (metrics + logs) |

### Blueprints Addons (feature-flagged)

| Addon | Flag | Default |
|-------|------|---------|
| Karpenter | `enable_karpenter` | `true` |
| Velero | `enable_velero` | `true` |
| AWS LB Controller | `enable_aws_load_balancer_controller` | `true` |
| Metrics Server | `enable_metrics_server` | `true` |
| VPA | `enable_vpa` | `true` |
| CloudWatch Metrics | `enable_aws_cloudwatch_metrics` | `true` |
| Node Termination Handler | `enable_aws_node_termination_handler` | varies |
| Cluster Autoscaler | `enable_cluster_autoscaler` | `false` (Karpenter used instead) |
| FluentBit | `enable_aws_for_fluentbit` | `false` (Loki/Promtail/Grafana used) |

### Helm Releases (deployed via `helm_releases` map)

| Chart | Version | Purpose |
|-------|---------|---------|
| Cilium | 1.16.5 | Service mesh with Hubble UI (chaining mode, not CNI replacement) |
| Kyverno | 3.3.4 | Policy engine (runs on on-demand nodes) |
| KEDA | 2.16.1 | Event-driven autoscaling |
| Goldilocks | 9.0.1 | VPA-based right-sizing dashboard |
| Kubetail | 0.6.0 | Cluster-wide log tailing UI |
| Prometheus Adapter | 4.11.0 | Custom metrics API for HPA |

---

## Repository Structure

```
.
├── main.tf              # Root module: providers, EKS cluster, addons, supporting resources
├── variables.tf         # All input variables with defaults
├── versions.tf          # Terraform and provider version constraints
├── backend.tf           # S3 backend configuration
├── outputs.tf           # Root outputs
├── nodepool.yaml        # Karpenter NodePool + EC2NodeClass (templated)
│
├── vars/                # One tfvars file per cluster
│   ├── ag-devops-ap-136.tfvars
│   ├── ag-noprod-ap-136.tfvars
│   └── ag-prd-ap-136.tfvars
│
├── eks/                 # EKS cluster module (node groups, OIDC, etc.)
│   ├── main.tf
│   ├── node_groups.tf
│   ├── variables.tf
│   ├── outputs.tf
│   ├── versions.tf
│   ├── modules/         # Sub-modules (karpenter, aws-auth, etc.)
│   └── templates/       # User data templates (AL2023, Bottlerocket)
│
├── eks_addons/          # Blueprints addons module
│   ├── main.tf
│   ├── helm.tf
│   ├── variables.tf
│   ├── outputs.tf
│   └── versions.tf
│
├── .gitlab-ci.yml       # GitLab CI (SAST scanning)
└── README.md
```

---

## Deployment

### Prerequisites

Before creating a new cluster, ensure:

1. **VPC is provisioned** with:
   - Node subnets (private, across 2-3 AZs)
   - Pod subnets (non-routable, for VPC CNI custom networking)
   - NAT Gateway for pod egress
   - Subnets tagged with `karpenter.sh/ekscluster = <cluster_name>`

2. **KMS Keys exist** (in the same region):
   - Cluster secrets encryption key → passed as `TF_VAR_cluster_kms_key_arn`
   - Velero S3 bucket encryption key → passed as `TF_VAR_velero_kms_key_arn`

3. **IAM Role** for Terraform/Jenkins to assume exists in the target account

4. **S3 Backend Bucket** exists for Terraform state storage

5. **CI/CD Pipeline Variables** are configured:
   | Variable | Description |
   |----------|-------------|
   | `TF_VAR_ACCOUNT_ID` | Target AWS Account ID |
   | `TF_VAR_ROLE_NAME` | IAM role name to assume (e.g. `Jenkins`) |
   | `TF_VAR_cluster_kms_key_arn` | KMS key ARN for secrets encryption |
   | `TF_VAR_velero_kms_key_arn` | KMS key ARN for Velero S3 bucket |

### Deploy a Cluster

```bash
# Initialize with cluster-specific state key
terraform init \
  -backend-config="key=eks/<cluster_name>/terraform.tfstate" \
  -backend-config="bucket=tf-backend-<account>-ap" \
  -backend-config="region=ap-southeast-1"

# Plan
terraform plan -var-file=vars/ag-devops-ap-136.tfvars

# Apply
terraform apply -var-file=vars/ag-devops-ap-136.tfvars
```

### Jenkins Pipeline (typical)

```groovy
stage('Terraform Plan') {
    environment {
        TF_VAR_ACCOUNT_ID         = credentials('aws-account-id')
        TF_VAR_ROLE_NAME          = 'Jenkins'
        TF_VAR_cluster_kms_key_arn = credentials('cluster-kms-key-arn')
        TF_VAR_velero_kms_key_arn  = credentials('velero-kms-key-arn')
    }
    steps {
        sh """
            terraform init -backend-config="key=eks/${CLUSTER_NAME}/terraform.tfstate"
            terraform plan -var-file=vars/${TFVARS_FILE} -out=tfplan
        """
    }
}
```

---

## Cluster Upgrade Process (Blue/Green)

This repo uses a **blue/green** strategy for Kubernetes version upgrades. Both old and new clusters run simultaneously during migration.

### Steps

1. **Create new tfvars** — copy the current file with the new version suffix:
   ```bash
   cp vars/ag-devops-ap-136.tfvars vars/ag-devops-ap-138.tfvars
   ```

2. **Update the new tfvars**:
   - `cluster_version = "1.38"`
   - `cluster_name = "ag-devops-ap-138"` (new name to avoid conflict)
   - Update `karpenter.sh/ekscluster` tag in `launch_template_tags`
   - Bump helm chart versions if needed

3. **Deploy new cluster** with a separate state key:
   ```bash
   terraform init -backend-config="key=eks/ag-devops-ap-138/terraform.tfstate"
   terraform apply -var-file=vars/ag-devops-ap-138.tfvars
   ```

4. **Validate** — deploy test workloads, verify addons, run smoke tests

5. **Migrate workloads** — update DNS, ArgoCD targets, etc. to point to new cluster

6. **Destroy old cluster**:
   ```bash
   # Empty Velero S3 bucket first (force_destroy=false protects it)
   aws s3 rm s3://<old-cluster-velero-bucket> --recursive

   terraform init -backend-config="key=eks/ag-devops-ap-136/terraform.tfstate"
   terraform destroy -var-file=vars/ag-devops-ap-136.tfvars
   ```

7. **Cleanup** — delete old tfvars file, commit

### Naming Convention

```
ag-<environment>-ap-<k8s_version_without_dot>.tfvars

Examples:
  ag-devops-ap-136.tfvars   → DevOps, EKS 1.36
  ag-noprod-ap-138.tfvars   → NonProd, EKS 1.38
  ag-prd-ap-140.tfvars      → Prod, EKS 1.40
```

---

## Standards & Best Practices

### Tagging

All resources receive 15 mandatory tags (defined in tfvars `tags` block) plus 2 computed tags (`Blueprint`, `karpenter.sh/ekscluster`). Total: 17 tags per resource.

Required tags:
```hcl
tags = {
  appcode, AppEnv, AwsEnv, Application, Name, Project, AwsId,
  archiving, backup, data-confidentiality, finops.automation.schedule,
  finops.id, info.eol, info.owner, msp
}
```

### Security

- No hardcoded credentials, account IDs, or KMS keys in code — all injected via CI/CD
- IMDSv2 enforced on all nodes
- Private API endpoint only
- KMS encryption for secrets and Velero backups
- S3 bucket: deny insecure transport, block public access, versioning enabled
- Kyverno policies enforce security standards at admission time

### Node Management

- No static AMI IDs — use `ami_type` and let EKS resolve the latest AMI
- Karpenter NodePool uses `alias: al2023@latest` for automatic AMI updates
- On-demand nodes for critical addons, spot for workloads
- Prefix delegation for efficient IP usage

### What NOT to Do

- ❌ Do not hardcode `ACCOUNT_ID`, `ROLE_NAME`, or KMS ARNs in tfvars
- ❌ Do not pin `ami_id` — let EKS manage AMI lifecycle
- ❌ Do not set `force_destroy = true` on Velero S3 buckets
- ❌ Do not use `cluster_autoscaler` and `karpenter` simultaneously
- ❌ Do not deploy FluentBit (Loki/Promtail/Grafana stack is used instead)
- ❌ Do not create branches per cluster — use single `master` branch with tfvars per cluster

---

## Environments

| Environment | Account | VPC | Subnets | tfvars | State Key |
|-------------|---------|-----|---------|--------|-----------|
| DevOps | 044063822467 | `vpc-035fb0864b4a079c5` | 3 AZs | `ag-devops-ap-136.tfvars` | `eks/ag-devops-ap-136/terraform.tfstate` |
| NonProd | 263975812908 | `vpc-04bbd4d0e7d108919` | 2 AZs | `ag-noprod-ap-136.tfvars` | `eks/ag-noprod-ap-136/terraform.tfstate` |
| Prod | 019480634551 | `vpc-0e9cf95c1cb90c8df` | 3 AZs | `ag-prd-ap-136.tfvars` | `eks/ag-prd-ap-136/terraform.tfstate` |

### Velero Backup Namespaces

| Cluster | Namespaces backed up |
|---------|---------------------|
| DevOps | All (no filter) |
| NonProd | `apac_dev`, `apac_sit`, `apac_uat` |
| Prod | `apac_prd` |

---

## Observability Stack

| Layer | Tool | Deployment |
|-------|------|------------|
| Metrics | CloudWatch Container Insights | EKS managed addon |
| Logs | Loki + Promtail + Grafana | External (not in this repo) |
| Service Mesh | Cilium + Hubble UI | Helm release |
| Right-sizing | Goldilocks + VPA | Helm release |
| Custom Metrics | Prometheus Adapter | Helm release |

---

## Terraform Version Requirements

```hcl
terraform >= 1.5.7, < 2.0.0
```

Provider versions are pinned in `versions.tf`.
